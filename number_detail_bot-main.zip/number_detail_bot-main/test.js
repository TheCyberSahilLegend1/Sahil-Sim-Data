let i = [];
if (!i[0]) {
  console.log("emtpy");
}
